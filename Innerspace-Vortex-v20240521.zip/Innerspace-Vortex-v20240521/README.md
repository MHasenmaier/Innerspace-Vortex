# Innerspace Vortex - A space war in your browser

![image](https://github.com/MHasenmaier/Innerspace-Vortex/assets/25233028/e2f7c922-7bfa-4a24-b7ca-f64bf8ce5804)

## Worum es geht

Innerspace Vortex (IV) ist ein old-school Browsergame im Genre "Weltraum".  


# TODO 